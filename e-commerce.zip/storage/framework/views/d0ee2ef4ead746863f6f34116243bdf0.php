<div id="hs-offcanvas-profile"
    class="hs-overlay hs-overlay-open:translate-x-0 hidden translate-x-full fixed top-0 end-0 transition-all duration-300 transform h-full max-w-xs w-full z-[1000] bg-white border-s border-gray-200 dark:bg-neutral-800 dark:border-neutral-700"
    role="dialog" tabindex="-1" aria-labelledby="hs-offcanvas-profile-label">
    <div
        class="flex justify-between items-center py-3 px-4 border-b border-gray-200 bg-coklattua dark:border-neutral-700">
        <h3 id="hs-offcanvas-profile-label" class="font-bold text-white">
            Profil Pengguna
        </h3>
        <button type="button"
            class="size-8 inline-flex justify-center items-center gap-x-2 rounded-full border border-transparent bg-coklatmuda-100 text-coklattua hover:bg-coklatmuda-100/80 focus:outline-hidden focus:bg-coklatmuda-100/90 disabled:opacity-50 disabled:pointer-events-none"
            aria-label="Close" data-hs-overlay="#hs-offcanvas-profile">
            <span class="sr-only">Close</span>
            <svg class="shrink-0 size-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                stroke-linejoin="round">
                <path d="M18 6 6 18"></path>
                <path d="m6 6 12 12"></path>
            </svg>
        </button>
    </div>
    <div class="p-4 bg-coklatmuda-100 h-full overflow-y-auto">
        <?php if(auth()->guard()->check()): ?>
            <div class="space-y-4">
                <div class="flex items-center space-x-4">
                    <div
                        class="flex-shrink-0 size-16 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 font-bold text-xl">
                        <?php echo e(Str::substr(Auth::user()->name, 0, 1)); ?>

                    </div>
                    <div>
                        
                        <p class="font-semibold text-white"><?php echo e(Auth::user()->name); ?></p>
                        <p class="text-sm text-gray-200"><?php echo e(Auth::user()->email); ?></p> 
                    </div>
                </div>

                <hr class="border-gray-400"> 

                <h4 class="font-semibold text-white">Informasi Kontak:</h4> 
                <p class="text-gray-200 text-sm"> 
                    Alamat: <?php echo e(Auth::user()->address ?? 'Belum ada alamat'); ?> <br>
                    Telepon: <?php echo e(Auth::user()->phone_number ?? 'Belum ada telepon'); ?>

                </p>

                <hr class="border-gray-400">

                <h4 class="font-semibold text-white">Opsi Akun:</h4> 
                <ul class="space-y-2">
                    <li>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="flex items-center text-red-400 hover:text-red-500 text-sm font-medium">
                                
                                <svg class="size-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                </svg>
                                Log Out
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        <?php else: ?>
            <p class="text-white">Anda belum login. <a href="<?php echo e(route('login')); ?>"
                    class="text-blue-200 hover:underline">Login di sini</a>.</p> 
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\laragon\www\e-commerce\resources\views/profil/profil.blade.php ENDPATH**/ ?>