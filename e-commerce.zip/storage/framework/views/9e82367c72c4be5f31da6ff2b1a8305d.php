
<?php $__env->startSection('container'); ?>
    <?php if(Session()->has('authError')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
            <strong class="font-bold">Perhatian!</strong>
            <span class="block sm:inline"><?php echo e(session('authError')); ?></span>
        </div>
    <?php endif; ?>
    <div class="flex items-center h-screen justify-center ">
        <div class="w-full max-w-sm p-8 backdrop-blur-3xl bg-coklattua rounded-2xl shadow-lg">
            <?php if(Session()->has('success')): ?>
                <?php echo $__env->make('alert.registrasialert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
            <?php if(Session()->has('loginError')): ?>
                <?php echo $__env->make('alert.loginalert', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>

            <h2 class="text-2xl font-bold text-center text-coklatmuda-100 drop-shadow-lg  mb-6">Login
            </h2>

            <form action="login" method="POST" class="space-y-5 ">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="email" class="block text-sm font-medium text-white mb-1">Email</label>
                    <input type="email" id="email" name="email" autofocus required value="<?php echo e(old('email')); ?>"
                        class="w-full px-4 py-2 border text-white border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500" />
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-sm text-red-600 " id="hs-validation-name-error-helper">
                        <?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div>
                    <label for="password" class="block text-sm font-medium text-white mb-1">Password</label>
                    <input type="password" id="password" name="password" required
                        class="w-full px-4 py-2 border text-white border-gray-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500" />
                </div>

                <button type="submit"
                    class="w-full bg-orange-500 text-white py-2 px-4 rounded-lg hover:bg-orange-400 hover:shadow-lg hover:shadow-orange-400/50 transition duration-200">
                    Login
                </button>
            </form>

            <p class="mt-6 text-center text-sm text-gray-400">
                Don't have an account?
                <a href="<?php echo e(route('registrasi')); ?>" class="text-blue-500 hover:underline">Sign up</a>
            </p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\e-commerce\resources\views/login/login.blade.php ENDPATH**/ ?>