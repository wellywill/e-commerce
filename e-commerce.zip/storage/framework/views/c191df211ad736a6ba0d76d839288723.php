 

<?php $__env->startSection('container'); ?>
    <div class="mx-auto max-w-2xl px-4 py-16 sm:px-6 sm:py-24 lg:max-w-7xl lg:px-8">
        <h1 class="text-3xl font-bold tracking-tight text-gray-900 mb-8">Informasi Checkout</h1>

        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                <strong class="font-bold">Sukses!</strong>
                <span class="block sm:inline"><?php echo e(session('success')); ?></span>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <strong class="font-bold">Gagal!</strong>
                <span class="block sm:inline"><?php echo e(session('error')); ?></span>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <strong class="font-bold">Ada kesalahan:</strong>
                <ul class="mt-2 list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="lg:grid lg:grid-cols-2 lg:gap-x-12 xl:gap-x-16">
            
            <div>
                <h2 class="text-lg font-medium text-gray-900 mb-4">Ringkasan Pesanan</h2>
                <div class="border-t border-gray-200 py-6">
                    <ul role="list" class="-my-6 divide-y divide-gray-200">
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItemId => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="flex py-6">
                                <div class="h-24 w-24 flex-shrink-0 overflow-hidden rounded-md border border-gray-200">
                                    <img src="<?php echo e(asset('storage/' . $details['image'])); ?>"
                                        alt="<?php echo e($details['product_name']); ?>"
                                        class="h-full w-full object-cover object-center">
                                </div>
                                <div class="ml-4 flex flex-1 flex-col">
                                    <div>
                                        <div class="flex justify-between text-base font-medium text-gray-900">
                                            <h3><?php echo e($details['product_name']); ?></h3>
                                            <p class="ml-4">
                                                Rp<?php echo e(number_format($details['price'] * $details['quantity'], 0, ',', '.')); ?>

                                            </p>
                                        </div>
                                        <p class="mt-1 text-sm text-gray-500">Qty: <?php echo e($details['quantity']); ?></p>
                                        <?php if(isset($details['color'])): ?>
                                            <p class="mt-1 text-sm text-gray-500">Color: <?php echo e($details['color']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="border-t border-gray-200 py-6 flex justify-between text-base font-medium text-gray-900">
                    <p>Total Harga</p>
                    <p>Rp<?php echo e(number_format($total, 0, ',', '.')); ?></p>
                </div>
            </div>

            
            <div class="mt-10 lg:mt-0">
                <h2 class="text-lg font-medium text-gray-900 mb-4">Alamat Pengiriman</h2>
                <form action="<?php echo e(route('checkout.process')); ?>" method="POST" class="space-y-6">
                    <?php echo csrf_field(); ?>

                    <div>
                        <label for="shipping_address" class="block text-sm font-medium text-gray-700">Alamat
                            Pengiriman</label>
                        <div class="mt-1">
                            <textarea id="shipping_address" name="shipping_address" rows="3" required
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md"></textarea>
                        </div>
                        <?php $__errorArgs = ['shipping_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    <button type="submit"
                        class="w-full flex items-center justify-center rounded-md border border-transparent bg-indigo-600 px-6 py-3 text-base font-medium text-white shadow-sm hover:bg-indigo-700">
                        Buat Pesanan
                    </button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\e-commerce\resources\views/checkout/checkout.blade.php ENDPATH**/ ?>